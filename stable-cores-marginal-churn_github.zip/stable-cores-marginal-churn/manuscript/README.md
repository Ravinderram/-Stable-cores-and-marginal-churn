# Manuscript source

| File | Content |
|---|---|
| `manuscript.tex` | Anonymized manuscript (single file; figures and tables placed next to their first mention) |
| `title_page.tex` | Title page with author details, CRediT statement and acknowledgements |
| `supplementary.tex` | Supplementary material (Tables S1-S21, Figs S1-S2), written by `code/r20/15_supplement.py` |
| `highlights.txt` | Highlights |
| `refs.bib` | Bibliography; fields named `verify` are not printed and list what is still to confirm |
| `figs/` | Figures as separate PDF files (copies of `figures/`) |
| `generated/` | LaTeX table fragments written by `13_tables.py` and `14_context_outputs.py` |
| `cas-dc.cls`, `cas-common.sty`, `elsarticle-num.bst`, `thumbnails/` | Elsevier CAS class files |

Compile (pdfLaTeX):

```sh
cd manuscript
pdflatex manuscript && bibtex manuscript && pdflatex manuscript && pdflatex manuscript
pdflatex supplementary && pdflatex supplementary
pdflatex title_page
```

On Overleaf, upload the `manuscript/` folder as a new project and set `manuscript.tex` as the main document.

The tables inside `manuscript.tex` are copies of the fragments in `generated/`. After rerunning the pipeline,
compare the two (for example with `diff`) and paste any changed table into `manuscript.tex`. Figures are read from
`figs/`; copy the new files from `figures/` if they changed.
